CREATE TABLE cities(
city_id INT,
city_name VARCHAR(50),
city_population BIGINT,
capital INT,
fact_id INT);